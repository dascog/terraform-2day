# Exercise 7b Terraform Cloud Backend Configuration (10 mins)
This tutorial follows the process of setting up a Terraform Cloud account and then using it from the Terraform command line. 
- https://learn.hashicorp.com/tutorials/terraform/aws-remote?in=terraform/aws-get-started
