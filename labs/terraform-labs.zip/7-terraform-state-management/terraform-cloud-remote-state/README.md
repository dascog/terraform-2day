# Exercise 7b Terraform Cloud Backend Configuration (10 mins)
- This tutorial follows the process of setting up a Terraform Cloud account and then using it from the Terraform command line. 
- It will run without modification, however you do need to have or create a Terraform Cloud account (a GitHub account is sufficient).
- https://learn.hashicorp.com/tutorials/terraform/aws-remote?in=terraform/aws-get-started
